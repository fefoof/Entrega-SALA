const express = require("express");
var router = express.Router();

const {
  renderSignUpForm,
  singup,
  renderSigninForm,
  signin,
  logout
} = require("../middlewares/user.middlewares");

// Routes
//router.get("/signup", renderSignUpForm);

router.post("/signup", singup);

//router.get("/signin", renderSigninForm);

router.post("/signin", signin);

router.get("/logout", logout);

module.exports = router;
