const express = require("express");
var router = express.Router();

// middlewares
const {
    renderIndex,
    renderAbout,
    getUser
  } = require("../middlewares/session.middlewares");

  const {
    autenticateUser
  } = require("../middlewares/autentication.middlewares");
  
  const {
    getAllPlayers,
    getPlayerById,    
    createNewPlayer,
    updatePlayer,
    deletePlayer
  } = require("../middlewares/player.middlewares");  

 //router.get("/players/add",  renderPlayerForm);
//router.post("/players/new-player", createNewPlayer);
// Editar Jugador
//router.get("/players/edit/:idPlayer", autenticateUser, renderEditForm);
//router.put("/players/edit-player/:idPlayer", autenticateUser, updatePlayer);
// Borrar Jugadores

// Todos 

router.get("/players/player/all", getAllPlayers);
router.get("/players/player/:idPlayer", getPlayerById);
router.post("/players/player/:idPlayer:", createNewPlayer);
router.put("/players/player/:idPlayer:name:surname", updatePlayer);
router.get("/players/player/:idPlayer", deletePlayer);


module.exports = router;
