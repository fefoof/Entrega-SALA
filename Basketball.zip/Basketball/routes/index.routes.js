const express = require("express");
var router = express.Router();

// middlewares
const {
    renderIndex,
    renderAbout,
    getUser
  } = require("../middlewares/session.middlewares");

  const {
    autenticateUser
  } = require("../middlewares/autentication.middlewares");
  
  const {
    renderSignUpForm,
    singup,
    renderSigninForm,
    signin,
    logout
  } = require("../middlewares/user.middlewares");  

router.get("/", getUser, autenticateUser, renderIndex);
//router.get('/', getUser, autenticateUser, getAllTasks, renderTask);

router.get("/about", renderAbout);

module.exports = router;