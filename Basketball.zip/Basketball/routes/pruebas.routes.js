const express = require("express");
var router = express.Router();

  const {
    getAllFields,
    getFieldById,    
    createNewField,
    updateField,
    deleteField
  } = require("../middlewares/Field.middlewares");  


  const {
    getAllGroups,
    getGroupById,    
    createNewGroup,
    updateGroup,
    deleteGroup
  } = require("../middlewares/Group.middlewares");  

  const {
    getAllLeagues,
    getLeagueById,    
    createNewLeague,
    updateLeague,
    deleteLeague
  } = require("../middlewares/League.middlewares");  

  const {
    getAllTeams,
    getTeamById,    
    createNewTeam,
    updateTeam,
    deleteTeam
  } = require("../middlewares/Team.middlewares");  

  const {
    getUser,
    singup,
    signin,
    logout
  } = require("../middlewares/User.middlewares");  
// Todos 

router.get("/Fields/Field/all", getAllFields);
router.get("/Fields/Field/:idField", getFieldById);
router.post("/Fields/Field/:idField:", createNewField);
router.put("/Fields/Field/:idField:name:surname", updateField);
router.get("/Fields/Field/:idField", deleteField);

router.get("/Groups/Group/all", getAllGroups);
router.get("/Groups/Group/:idGroup", getGroupById);
router.post("/Groups/Group/:idGroup:", createNewGroup);
router.put("/Groups/Group/:idGroup:name:surname", updateGroup);
router.get("/Groups/Group/:idGroup", deleteGroup);

router.get("/League/League/all", getAllLeagues);
router.get("/Leagues/League/:idLeague", getLeagueById);
router.post("/Leagues/League/:idLeague:", createNewLeague);
router.put("/Leagues/League/:idLeague:name:surname", updateLeague);
router.get("/Leagues/League/:idLeague", deleteLeague);

router.get("/Teams/Team/all", getAllTeams);
router.get("/Teams/Team/:idTeam", getTeamById);
router.post("/Teams/Team/:idTeam:", createNewTeam);
router.put("/Teams/Team/:idTeam:name:surname", updateTeam);
router.get("/Teams/Team/:idTeam", deleteTeam);

router.get("/Users/User/signin", signin);
router.get("/Users/User/:idUser", getUser);
router.put("/Users/User/:idUser:name:surname", singup);
router.get("/Users/User/logout", logout);



module.exports = router;
