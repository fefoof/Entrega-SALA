const express = require('express');
var bodyParser = require('body-parser');
const session = require('express-session');
var flash = require('connect-flash');

const app = express();

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }))
app.use(flash());

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');


/*app.use(function (req, res, next) {
    console.log('Time:', Date.now());
    next();
});*/

app.use(session({
    secret: 'my secret',
    cookie: {maxAge: 43200000},
    resave: false,
    saveUninitialized: true
}));

app.use(require('./routes/player.routes'));
app.use(require('./routes/user.routes'));
app.use(require('./routes/index.routes'));
app.use(require('./routes/pruebas.routes'));


app.listen(300, () => {
    console.log('Esta el servidor ejecutandose');
});