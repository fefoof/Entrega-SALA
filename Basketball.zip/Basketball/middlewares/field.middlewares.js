// Models
const Field = require('../models/field');

const renderFieldForm = (req, res) => {
  console.log('renderFieldForm');
  res.render("fields/new-field");
};

const createNewField = (req, res) => {
  const { idField,name,direction, phone } = (req.params.idField, req.params.name,req.params.direction, req.params.phone);
  const errors = [];
  if (!idField) {  
    errors.push({ text: "Debe ingresar el Id de la Cancha." });
  }
  if (!name) {
    errors.push({ text: "Debe ingresar el nombre." });
  }
  if (!direction) {
    errors.push({ text: "Debe ingresar el direccion." });
  }
  if (!phone) {
    errors.push({ text: "Debe ingresar el telefono." });
  }
  if (errors.length > 0) {
    res.json({
      errors:errors,
      idField:idField,
      name:name,
      direction:direction,
      phone:phone
    });
  } else {
    const newField = new Field({ idField,name,direction, phone });
    Field.saveField(idField,name,direction, phone  )
      .then(fieldrBD => {
        Field.getAllFields()
          .then(listFields => {   
              res.json({listFields});      
          })  
          .catch(err => {
            next(err);  
          });           
        
      })
      .catch(err => {
        next(err);  
      });  
  }
};

const updateField = (req, res, next) => {
  Field.findFieldByIdAndUpdate(req.params.idField, req.params.name,req.params.direction, req.params.phone)
    .then(fieldBD => {
      res.json({fieldBD}); 
    })
    .catch(err => {
      next(err);  
    }); 
};

const deleteField = async (req, res, next) => {
  Field.findByIdAndDelete(req.params.idField)
  .then(fieldBD => {
    res.json({fieldBD}); 
  })
  .catch(err => {
    next(err);  
  });      
};

/* const renderFields = (req, res) => {
    Field.getAllFields()
    .then(function(listFields){
      req.flash("success_msg", "Jugador dado de alta");
      res.render("fields/all-fields", { listFields });      
        //res.render("fields/all-fields", {message: "Usuario dado de alta"});
    })
    .catch(function(err){
      req.flash("success_msg", "Error dando de alta Jugador");
      res.render("index");  
        //res.render("fields/all-fields", {message: "Error dando de alta Jugador"});
    });    
};

const renderEditForm = (req, res) => {
  const field = Field.getFieldById(req.params.idField);
  res.render("fields/edit-field", { field });
};
 */



const getAllFields = (req, res, next) => {
  Field.getAllFields()
  .then(listFields => {
      res.json({listFields});
  })
  .catch(err => {
      next(err);  
  });    
};

const getFieldById = (req, res, next) => {
  Field.getField(req.params.idField)
    .then(fieldBD => {
      res.json({fieldBD}); 
    })
    .catch(err => {
      next(err);  
    });     
};


module.exports = {
    getAllFields,
    getFieldById,
    createNewField,
    updateField,
    deleteField
  };
