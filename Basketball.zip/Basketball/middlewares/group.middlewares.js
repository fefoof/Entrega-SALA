// Models
const Group = require('../models/group');

/* const renderGroupForm = (req, res) => {
  console.log('renderGroupForm');
  res.render("groups/new-group");
}; */

const createNewGroup = (req, res) => {
  const { idGroup,name,direction, phone } = req.body;
  const errors = [];
  if (!idGroup) {  
    errors.push({ text: "Debe ingresar el Id de la Cancha." });
  }
  if (!name) {
    errors.push({ text: "Debe ingresar el nombre." });
  }
  if (!direction) {
    errors.push({ text: "Debe ingresar el direccion." });
  }
  if (!phone) {
    errors.push({ text: "Debe ingresar el telefono." });
  }
  if (errors.length > 0) {
    res.render("group/new-group", {
      errors,
      idGroup,
      name,
      direction,
      phone
    });
  } else {
    const newGroup = new Group(  idGroup,name,direction, phone );
    Group.saveGroup( idGroup,name,direction, phone )
    .then(function(groupBD){
      req.flash("success_msg", "Cancha dado de alta");
      const listGroups = Group.getAllGroups();  
      res.render("groups/all-groups", { listGroups });      
        //res.render("groups/all-groups", {message: "Usuario dado de alta"});
    })
    .catch(function(err){
      req.flash("success_msg", "Error dando de alta Jugador");
      const listGroups = Group.getAllGroups();  
      res.render("groups/all-groups", { listGroups });  
        //res.render("groups/all-groups", {message: "Error dando de alta Jugador"});
    });    
  }
};
/* 

const renderGroups = (req, res) => {
    Group.getAllGroups()
    .then(function(listGroups){
      req.flash("success_msg", "Jugador dado de alta");
      res.render("groups/all-groups", { listGroups });      
        //res.render("groups/all-groups", {message: "Usuario dado de alta"});
    })
    .catch(function(err){
      req.flash("success_msg", "Error dando de alta Jugador");
      res.render("index");  
        //res.render("groups/all-groups", {message: "Error dando de alta Jugador"});
    });    
};

const renderEditForm = (req, res) => {
  const group = Group.getGroupById(req.params.idGroup);
  res.render("groups/edit-group", { group });
}; */

const updateGroup = (req, res) => {
  const {usuario, password,estado,idJugador,email,confirm_password} = req.body;
  Group.findGroupByIdAndUpdate(idJugador, {usuario, password,estado,idJugador,email,confirm_password} );
  req.flash("success_msg", "Jugador Actualizado");
  const listGroups = Group.getAllGroups();  
  res.render("groups/all-groups", { listGroups });
};

const deleteGroup = async (req, res) => {
    Group.findByIdAndDelete(req.params.idGroup);
  req.flash("success_msg", "Jugador Eliminado Correctamente");
  const listGroups = Group.getAllGroups();  
  res.render("groups/all-groups", { listGroups });
};


const getAllGroups = (req, res, next) => {
  Group.getAllGroups()
  .then(listGroups => {         
      res.json({listGroups});
  })
  .catch(err => {
      next(err);  
  });    
};

const getGroupById = (req, res, next) => {

  Group.getGroup(req.params.idGroup)
    .then(groupBD => {
      res.json({groupBD}); 
    })
    .catch(err => {
      next(err);  
    });     
};

module.exports = { 
  getAllGroups,  
  getGroupById, 
    createNewGroup,
    updateGroup,
    deleteGroup
  };
