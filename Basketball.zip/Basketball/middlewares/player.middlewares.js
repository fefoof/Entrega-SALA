// Models
const Player = require('../models/player');
const User = require('../models/user');

// Modules
//const passport = require("passport");
const bcrypt = require('bcrypt');

const createNewPlayer =  (req, res, next) => {
  const {idPlayer,name,surname, birthdate} = (req.params.idPlayer, req.params.name,req.params.surname, req.params.birthdate);
  const errors = [];
  if (!idPlayer) {  
    errors.push({ text: "Debe ingresar el Id de jugador." });
  }
  if (!name) {
    errors.push({ text: "Debe ingresar el nombre." });
  }
  if (!surname) {
    errors.push({ text: "Debe ingresar el apellido." });
  }
  if (!birthdate) {
    errors.push({ text: "Debe ingresar la fecha de nacimiento." });
  }
  if (errors.length > 0) {


    res.json({ 
      errors : errors, 
      idPlayer: idPlayer,
      name: name,
      surname: surname,
      birthdate: birthdate });
  } else {
    const newPlayer = new Player({ idPlayer,name,surname, birthdate });
    Player.savePlayer(idPlayer,name,surname, birthdate )
      .then(playerBD => {
          Player.getAllPlayers()
          .then(listPlayers => {
              //res.render("players/all-players", { listPlayers });    
              res.json({listPlayers});      
          })  
          .catch(err => {
            next(err);  
          });           
        
      })
      .catch(err => {
        next(err);  
      });    
  }
};

const updatePlayer = (req, res, next) => {
  //const {idPlayer,name,surname, birthdate} = req.body;
  Player.updatePlayer(req.params.idPlayer, req.params.name,req.params.surname, '010101')
    .then(playerBD => {
      res.json({playerBD}); 
    })
    .catch(err => {
      next(err);  
    });   
};

const deletePlayer = (req, res, next) => {
    User.deleteUserByPlayer(req.params.idPlayer)
    .then(playerBD => {
        Player.deletePlayer(req.params.idPlayer)
        .then(playerBD => {
          res.json({playerBD}); 
        })
        .catch(err => {
          next(err);  
        });    
    })
    .catch(err => {
      next(err);  
    }); 
};

const getAllPlayers = (req, res, next) => {
  Player.getAllPlayers()
  .then(listPlayers => {
      //res.render("players/all-players", { listPlayers });            
      res.json({listPlayers});
  })
  .catch(err => {
      next(err);  
  });    
};

const getPlayerById = (req, res, next) => {
  //const {idPlayer,name,surname, birthdate} = req.body;
  Player.getPlayer(req.params.idPlayer)
    .then(playerBD => {
      res.json({playerBD}); 
    })
    .catch(err => {
      next(err);  
    });     
};

/* const renderPlayerForm = (req, res) => {
  console.log('renderPlayerForm');
  res.render("players/new-player");
};

const renderPlayers = (req, res) => {
    Player.getAllPlayers()
    .then(function(listPlayers){
      req.flash("success_msg", "Jugador dado de alta");
      res.render("players/all-players", { listPlayers });      
        //res.render("players/all-players", {message: "Usuario dado de alta"});
    })
    .catch(function(err){
      req.flash("success_msg", "Error dando de alta Jugador");
      res.render("index");  
        //res.render("players/all-players", {message: "Error dando de alta Jugador"});
    });    
};

const renderEditForm = (req, res) => {
  const player = Player.getPlayerById(req.params.idPlayer);
  res.render("players/edit-player", { player });
};
 */

module.exports = {
    getAllPlayers,
    getPlayerById,
    createNewPlayer,
    updatePlayer,
    deletePlayer
  };
