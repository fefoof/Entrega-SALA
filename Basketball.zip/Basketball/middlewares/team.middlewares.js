// Models
const Team = require('../models/team');


/* const renderTeamForm = (req, res) => {
  console.log('renderTeamForm');
  res.render("teams/new-team");
};
 */
const createNewTeam = async (req, res) => {
  const { idteam,name,state, logo } = req.body;
  const errors = [];
  if (!idteam) {  
    errors.push({ text: "Debe ingresar el Id de team." });
  }
  if (!name) {
    errors.push({ text: "Debe ingresar el nombre." });
  }
  if (errors.length > 0) {
    res.render("teams/new-team", {
      errors,
      idteam,name,state, logo
    });
  } else {
    const newTeam = new Team({ idteam,name,state, logo });
    //newNote.user = req.user.id;
    Team.saveTeam(idteam,name,state, logo)
    .then(function(teamBD){
      req.flash("success_msg", "Equipo dado de alta");
      const listTeams = Team.getAllTeams();  
      res.render("teams/all-teams", { listTeams });      
        //res.render("teams/all-teams", {message: "Usuario dado de alta"});
    })
    .catch(function(err){
      req.flash("success_msg", "Error dando de alta el Equipos");
      const listTeams = Team.getAllTeams();  
      res.render("teams/all-teams", { listTeams });  
        //res.render("teams/all-teams", {message: "Error dando de alta Jugador"});
    });    
  }
};


/* const getAllteams = (req, res, next) => {
  connection.query("SELECT * FROM task", (err, result, fields) => {
      if (err) {
          throw err;
      } else {
          res.tasks = result;
          next();
      }
  });
}

const renderTask = (req, res, next) => {
  res.render('tasks',{
      tasks: res.tasks
  });
}
 */
/* const renderTeams = (req, res) => {
    Team.getAllTeams()
    .then(function(listTeams){
      req.flash("success_msg", "Equipo dado de alta");
      res.render("teams/all-teams", { listTeams });      
        //res.render("teams/all-teams", {message: "Usuario dado de alta"});
    })
    .catch(function(err){
      req.flash("success_msg", "Error dando de alta Equipo");
      res.render("index");  
        //res.render("teams/all-teams", {message: "Error dando de alta Jugador"});
    });    
};

const renderEditForm = (req, res) => {
  const team = Team.getTeamById(req.params.idTeam);
  res.render("teams/edit-team", { team });
}; */

const updateTeam = (req, res) => {
  const {idteam,name,state, logo} = req.body;
  Team.findTeamByIdAndUpdate(idteam,name,state, logo);
  req.flash("success_msg", "Equipo Actualizado");
  const listTeams = Team.getAllTeams();  
  res.render("teams/all-teams", { listTeams });
};

const deleteTeam = async (req, res) => {
    Team.findByIdAndDelete(req.params.idTeam);
  req.flash("success_msg", "Equipo Eliminado Correctamente");
  const listTeams = Team.getAllTeams();  
  res.render("teams/all-teams", { listTeams });
};

const getAllTeams = (req, res, next) => {
  Team.getAllTeams()
  .then(listTeams => {           
      res.json({listTeams});
  })
  .catch(err => {
      next(err);  
  });    
};

const getTeamById = (req, res, next) => {
  Team.getPlayer(req.params.idTeam)
    .then(teamBD => {
      res.json({teamBD}); 
    })
    .catch(err => {
      next(err);  
    });     
};

module.exports = {
  getAllTeams,
  getTeamById,
    createNewTeam,
    updateTeam,
    deleteTeam
  };
