const  renderIndex = (req, res) => {
  res.render('index');
};

const  renderAbout = (req, res) => {
    res.render('about');
  };


const getUser = (req, res, next) => {

    if(req.session.user){
        req.user = req.session.user;
    }
    next();
}

module.exports = {
    getUser,
    renderIndex,
    renderAbout
   }
   
  