

const autenticateUser = (req, res, next) => {
    console.log(req.session.user);
    if(req.session.user/*  == 'nuevo' */){
       next();
    }else{
        res.render("signin",{message: 'No autorizado'});
    }
    
}

module.exports = {
   autenticateUser
}