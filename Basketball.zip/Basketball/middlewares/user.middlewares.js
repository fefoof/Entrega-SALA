// Models
const User = require('../models/user');

// Modules
const passport = require("passport");
const bcrypt = require('bcrypt');

/* const  renderSignUpForm = (req, res) => {
  res.render('signup');
};
 */
const singup = (req, res) => {
  let errors = [];  
  //const {user:usuario, password,estado,idJugador,email,confirm_password} = req.body;
  const {user,usuario,password, estado,idJugador,email,confirm_password} = (req.params.user, req.params.usuario,req.params.password, req.params.estado,  req.params.idJugador, req.params.email, req.params.confirm_password);  
  if (password != confirm_password) {
    errors.push({ text: "Passwords do not match." });
  }
  if (password.length < 4) {
    errors.push({ text: "Passwords must be at least 4 characters." });
  }
  if (errors.length > 0) {


    res.json({ 
      errors:errors,
      usuario:usuario,
      email:email,
      password:password,
      confirm_password:confirm_password
     });

/*     res.render("/signup", {
      errors,
      usuario,
      email,
      password,
      confirm_password
    }); */
  } else {
    // Look for email coincidence
//    const emailUser = await User .getUserByEmail({ email: email });
    User.getUserByEmail(email)
        .then(function(userSave){
          //console.log(req.body);
          const saltRounds = 10;
          bcrypt.hash(password, saltRounds, function(err, hash) {
 
            User.saveUser(usuario, hash,'A',idJugador,email)
              .then(function(userSave){       
                  //req.flash("success_msg", "You are registered.");
                  //res.redirect("signin", "Usuario dado de alta");
                  //res.render("signin", {message: "Usuario dado de alta"});
                  res.json("signin");
              })
              .catch(function(err){
                  console.log(err);
              });
          });              
        })  
        .catch(function(err){
          console.log(err);
          //req.flash("success_msg", "You are registered.");
          //res.redirect("/signin");
        });
      /*
    if (emailUser) {
      req.flash("error_msg", "The Email is already in use.");
      res.redirect("/signup");
    } else {
      // Saving a New User
      //const newUser = new User({usuario, password,estado,idJugador,email});      
      //newUser.password = await newUser.encryptPassword(password);
      await User.saveUser(usuario, password,estado,idJugador,email);
      req.flash("success_msg", "You are registered.");
      res.redirect("/signin");
    }
    */
  }
};


/*
const renderSigninForm = (req, res) => {
  res.render("signin", {message: null});
};

 const signin = passport.authenticate("local", {
    successRedirect: "/notes",
    failureRedirect: "/signin",
    failureFlash: true
  }); */

const signin = (req, res) => {
    const { user, password } = req.body;
    User.getUser(user)
    .then(function(userBase){

      if (userBase) {
        console.log(userBase.password);
        bcrypt.compare(password, userBase.password, function (err, compareResult) {
            console.log(compareResult);
            if (compareResult) {
                req.session.user = user;
                res.render('index', {message: 'Login con exito'});
            }else{
                res.render("signin", {message: 'Usuario y/o contraseña incorrecta.'});
            }
        });
      }else{
          res.render("signin", {message: 'Usuario y/o contraseña incorrecta.'});
      }      

    })  
    .catch(function(err){
      console.log(err);
    });
};  

const logout = (req, res) => {
  req.logout();
  req.flash("success_msg", "You are logged out now.");
  res.redirect("/signin");
};

const getUser = (req, res) => {
  const {user} = (req.params.idUser);  
  //const { user, password } = req.body;
  User.getUser(user)
  .then(function(userBase){
      res.json(userBase); 
  })  
  .catch(function(err){
    console.log(err);
  });
};  

module.exports = {
  getUser,
  //renderSignUpForm,
  singup,
  //renderSigninForm,
  signin,
  logout
}