// Models
const League = require('../models/league');


const createNewLeague = (req, res, next) => {
  const { idLeague,name,direction, phone } = (req.params.idLeague, req.params.name,req.params.direction, req.params.phone);  
  const errors = [];
  if (!idLeague) {  
    errors.push({ text: "Debe ingresar el Id de la Cancha." });
  }
  if (!name) {
    errors.push({ text: "Debe ingresar el nombre." });
  }
  if (!direction) {
    errors.push({ text: "Debe ingresar el direccion." });
  }
  if (!phone) {
    errors.push({ text: "Debe ingresar el telefono." });
  }
  if (errors.length > 0) {
    res.json({
      errors:errors,
      idLeague:idLeague,
      name:name,
      direction:direction,
      phone:phone
    });
  } else {
    const newLeague = new League(  idLeague,name,direction, phone );
    League.saveLeague( idLeague,name,direction, phone )
    .then(leagueBD => {
      League.getAllLeagues()
        .then(listLeagues => {
            res.json({listLeagues});      
        })  
        .catch(err => {
            next(err);  
        });  
    })
    .catch(err => {
        next(err);  
    });    
  }
};


const updateLeague = (req, res, next) => {
  //const {usuario, password,estado,idJugador,email,confirm_password} = req.body;
  League.findLeagueByIdAndUpdate(req.params.idLeague, req.params.name,req.params.direction, req.params.phone)
  .then(leagueBD => {
    res.json({leagueBD}); 
  })
  .catch(err => {
    next(err);  
  }); 
};

const deleteLeague = (req, res, next) => {
    League.findByIdAndDelete(req.params.idLeague)
    .then(leagueBD => {
      res.json({leagueBD}); 
    })
    .catch(err => {
      next(err);  
    }); 
};

const getAllLeagues = (req, res, next) => {
  League.getAllLeagues()
  .then(listLeagues => {         
      res.json({listLeagues});
  })
  .catch(err => {
      next(err);  
  });    
};

const getLeagueById = (req, res, next) => {
  League.getLeague(req.params.idLeague)
    .then(leagueBD => {
      res.json({leagueBD}); 
    })
    .catch(err => {
      next(err);  
    });     
};

/* const renderLeagueForm = (req, res) => {
  console.log('renderLeagueForm');
  res.render("leagues/new-league");
};

const renderLeagues = (req, res) => {
    League.getAllLeagues()
    .then(function(listLeagues){
      req.flash("success_msg", "Jugador dado de alta");
      res.render("leagues/all-leagues", { listLeagues });      
        //res.render("leagues/all-leagues", {message: "Usuario dado de alta"});
    })
    .catch(function(err){
      req.flash("success_msg", "Error dando de alta Jugador");
      res.render("index");  
        //res.render("leagues/all-leagues", {message: "Error dando de alta Jugador"});
    });    
};

const renderEditForm = (req, res) => {
  const league = League.getLeagueById(req.params.idLeague);
  res.render("leagues/edit-league", { league });
};
 */


module.exports = {
    createNewLeague,
    getAllLeagues,
    getLeagueById,
    updateLeague,
    deleteLeague
  };
