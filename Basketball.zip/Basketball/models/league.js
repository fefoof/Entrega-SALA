const dbCOnn = require('../database');
const GET_LEAGUE='SELECT * FROM LEAGUE WHERE IDLEAGUE=?';
const GET_LEAGUE_BY_NAME='SELECT * FROM LEAGUE WHERE NAME=?';
const GET_ALL_LEAGUES='SELECT * FROM LEAGUE';
const POST_NEW_LEAGUE='INSERT INTO LEAGUE SET ?';
const UPDATE_GROUP='UPDATE LEAGUE SET name=?, description=? WHERE idLeague=?';
const DELETE_GROUP='DELETE FROM LEAGUE WHERE IDLEAGUE=?';

class League{
    constructor(idLeague,name,description){
        this.idLeague = idLeague;
        this.name = name;
        this.description = description;
    }

    static saveLeague(idLeague,name,description){
        console.log('saveLeague');
        return new Promise(function (resolve,reject){

                const newLeague  = { 
                    idLeague,name,description
                };
                dbCOnn.query(POST_NEW_LEAGUE, newLeague, function (error, result){
                    if (error){
                        reject(error);
                    }else{
                        resolve(new League(idLeague,name,description))
                    }
                });

        })
    }        

    static getLeague(idLeague){
        return new Promise(function (resolve,reject){
            dbCOnn.query(GET_LEAGUE, [idLeague], function (error, result){
                if (error){
                    reject(error);
                }else{
                    const {idLeague,name,description} = result[0];
                    resolve(new League(idLeague,name,description));
                }
            });
        })
        
    }

    static getLeagueByName(name){
        console.log('getLeagueByName');
        return new Promise(function (resolve,reject){
            console.log('getLeagueByName db');
            dbCOnn.query(GET_LEAGUE_BY_NAME, [name], function (error, result){
                if (error){
                    reject(error);
                
                }else{
                    console.log('else');
                    if (result[0]){
                        console.log('encontro');
                        const {idLeague,name,description} = result[0];
                        resolve(new League(idLeague,name,description))
                    }else{
                        console.log('not found');
                        resolve('NOT Found');    
                    }
                    
                }
            });
        })
        
    }    

    static getAllLeagues(){
        console.log('getAllLeagues');
        return new Promise(function (resolve,reject){
            console.log('getAllLeagues db');
            dbCOnn.query(GET_ALL_LEAGUES, function (error, result){
                if (error){
                    reject(error);                
                }else{
                    console.log('else');
                    if (result[0]){
                        console.log('encontro');
                        resolve(result)
                    }else{
                        console.log('not found');
                        resolve('NOT Found');    
                    }
                    
                }
            });
        })
        
    } 
    static updateLeague(idLeague,name,description){
        console.log('updateLeague');
        return new Promise(function (resolve,reject){
                const updateLeague  = { 
                    name,description,idLeague
                };
                dbCOnn.query(UPDATE_LEAGUE, [updateLeague], function (error, result){
                    if (error){
                        reject(error);
                    }else{
                        resolve(new Group(idLeague,name,description))
                    }
                });

        })
    }


    static deleteLeague(idLeague){
        console.log('deleteLeague');
        return new Promise(function (resolve,reject){      

                        dbCOnn.query(DELETE_LEAGUE, [idGroup], function (error, result){
                            if (error){
                                reject(error);
                            }else{
                                resolve(result);  
                            }
                        });
          
        })
    }

}

module.exports = League;
