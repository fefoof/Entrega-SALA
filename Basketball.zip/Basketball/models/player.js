const dbCOnn = require('../database');
const usuario = require('../models/user');

const GET_PLAYER='SELECT * FROM PLAYER WHERE IDPLAYER=?';
const GET_PLAYER_BY_NAME='SELECT * FROM PLAYER WHERE NAME=?';
const GET_ALL_PLAYERS='SELECT * FROM PLAYER';
const POST_NEW_PLAYER='INSERT INTO PLAYER SET ?';
const UPDATE_PLAYER='UPDATE PLAYER SET name=?, surname=?, birthdate=? WHERE IDPLAYER=?';
const DELETE_PLAYER='DELETE FROM PLAYER WHERE IDPLAYER=?';


class Player{
    constructor(idPlayer,name,surname, birthdate){
        this.idPlayer = idPlayer;
        this.name = name;
        this.surname = surname;
        this.birthdate = birthdate;

    }

    static savePlayer(idPlayer,name,surname, birthdate){
        console.log('savePlayer');
        return new Promise(function (resolve,reject){

                const newPlayer  = { 
                    idPlayer,name,surname, birthdate
                };
                dbCOnn.query(POST_NEW_PLAYER, newPlayer, function (error, result){
                    if (error){
                        reject(error);
                    }else{
                        resolve(new Player(idPlayer,name,surname, birthdate))
                    }
                });

        })
    }        

    static getPlayerById(player){
        return new Promise(function (resolve,reject){
            dbCOnn.query(GET_PLAYER, [player], function (error, result){
                if (error){
                    reject(error);
                }else{
                    resolve(result);
                }
            });
        })
        
    }

    static getPlayerByEmail(email){
        console.log('getPlayerByEmail');
        return new Promise(function (resolve,reject){
            console.log('getPlayerByEmail db');
            dbCOnn.query(GET_PLAYER_BY_EMAIL, [email], function (error, result){
                if (error){
                    reject(error);
                
                }else{
                    console.log('else');
                    if (result[0]){
                        resolve(result)
                    }else{
                        console.log('not found');
                        resolve('NOT Found');    
                    }
                    
                }
            });
        })
        
    }   
    
    static updatePlayer(idPlayer,name,surname,birthdate){
        console.log('UpdatePlayer');
        return new Promise(function (resolve,reject){
                const updatePlayer  = { 
                    name,surname, birthdate,idPlayer
                };
                dbCOnn.query(UPDATE_PLAYER, [updatePlayer], function (error, result){
                    if (error){
                        reject(error);
                    }else{
                        resolve(new Player(idPlayer,name,surname, birthdate))
                    }
                });

        })
    }


    static deletePlayer(idPlayer){
        console.log('deletePlayer');
        return new Promise(function (resolve,reject){      
/*                 dbCOnn.query(DELETE_USER, [idPlayer], function (error, result){
                    if (error){
                        reject(error);
                    }else{ */
                        dbCOnn.query(DELETE_PLAYER, [idPlayer], function (error, result){
                            if (error){
                                reject(error);
                            }else{
                                resolve(result);  
                            }
                        });
/*                     }
                });      */        
        })
    }
    

    static getAllPlayers(){
        console.log('getAllPlayers');
        return new Promise(function (resolve,reject){
            console.log('getAllPlayers db');
            dbCOnn.query(GET_ALL_PLAYERS, function (error, result){
                if (error){
                    reject(error);                
                }else{
                    console.log('else');
                    if (result[0]){
                        console.log('encontro');
                        resolve(result)
                    }else{
                        console.log('not found');
                        resolve('NOT Found');    
                    }
                    
                }
            });
        })
        
    } 
}




module.exports = Player;
