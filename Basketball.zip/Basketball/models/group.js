const dbCOnn = require('../database');
const GET_GROUP='SELECT * FROM GROUP WHERE IDGROUP=?';
const GET_GROUP_BY_NAME='SELECT * FROM GROUP WHERE NAME=?';
const GET_ALL_GROUPS='SELECT * FROM GROUP';
const POST_NEW_GROUP='INSERT INTO GROUP SET ?';
const UPDATE_GROUP='UPDATE GROUP SET name=?, idChampionship=? WHERE IDGROUP=?';
const DELETE_GROUP='DELETE FROM GROUP WHERE IDGROUP=?';

class Group{
    constructor(idGroup,name,idChampionship){
        this.idGroup = idGroup;
        this.name = name;
        this.idChampionship = idChampionship;

    }

    static saveGroup(idGroup,name,idChampionship){
        console.log('saveGroup');
        return new Promise(function (resolve,reject){

                const newGroup  = { 
                    idGroup,name,idChampionship
                };
                dbCOnn.query(POST_NEW_GROUP, newGroup, function (error, result){
                    if (error){
                        reject(error);
                    }else{
                        resolve(new Group(idGroup,name,idChampionship))
                    }
                });

        })
    }        

    static getGroup(group){
        return new Promise(function (resolve,reject){
            dbCOnn.query(GET_GROUP, [group], function (error, result){
                if (error){
                    reject(error);
                }else{
                    const {idGroup,name,idChampionship} = result[0];
                    resolve(new Group(idGroup,name,idChampionship));
                }
            });
        })
        
    }

    static getGroupByName(name){
        console.log('getGroupByName');
        return new Promise(function (resolve,reject){
            console.log('getGroupByName db');
            dbCOnn.query(GET_GROUP_BY_NAME, [name], function (error, result){
                if (error){
                    reject(error);
                
                }else{
                    console.log('else');
                    if (result[0]){
                        console.log('encontro');
                        const {idGroup,name,idChampionship} = result[0];
                        resolve(new Group(idGroup,name,idChampionship))
                    }else{
                        console.log('not found');
                        resolve('NOT Found');    
                    }
                    
                }
            });
        })
        
    }    

    static getAllGroups(){
        console.log('getAllGroups');
        return new Promise(function (resolve,reject){
            console.log('getAllGroups db');
            dbCOnn.query(GET_ALL_GROUPS, function (error, result){
                if (error){
                    reject(error);                
                }else{
                    console.log('else');
                    if (result[0]){
                        console.log('encontro');
                        resolve(result)
                    }else{
                        console.log('not found');
                        resolve('NOT Found');    
                    }
                    
                }
            });
        })
        
    } 



    static updateGroup(idGroup,name,idChampionship){
        console.log('updateGroup');
        return new Promise(function (resolve,reject){
                const updategroup  = { 
                    name,surname, birthdate,idGroup
                };
                dbCOnn.query(UPDATE_GROUP, [updateGroup], function (error, result){
                    if (error){
                        reject(error);
                    }else{
                        resolve(new Group(idGroup,name,idChampionship))
                    }
                });

        })
    }


    static deleteGroup(idGroup){
        console.log('deleteGroup');
        return new Promise(function (resolve,reject){      

                        dbCOnn.query(DELETE_GROUP, [idGroup], function (error, result){
                            if (error){
                                reject(error);
                            }else{
                                resolve(result);  
                            }
                        });
          
        })
    }

}

module.exports = Group;
