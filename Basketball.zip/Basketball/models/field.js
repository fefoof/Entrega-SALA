const dbCOnn = require('../database');
const GET_FIELD='SELECT * FROM FIELD WHERE IDFIELD=?';
const GET_FIELD_BY_NAME='SELECT * FROM FIELD WHERE NAME=?';
const GET_ALL_FIELDS='SELECT * FROM FIELD';
const POST_NEW_FIELD='INSERT INTO FIELD SET ?';
const UPDATE_FIELD='UPDATE PLAYER SET name=?, direction=?, phone=? WHERE idField=?';
const DELETE_FIELD='DELETE FROM FIELD WHERE IDFIELD=?';


class Field{
    constructor(idField,name,direction, phone){
        this.idField = idField;
        this.name = name;
        this.direction = direction;
        this.phone = phone;

    }

    static saveField(idField,name,direction, phone){
        console.log('saveField');
        return new Promise(function (resolve,reject){

                const newField  = { 
                    idField,name,direction, phone
                };
                dbCOnn.query(POST_NEW_FIELD, newField, function (error, result){
                    if (error){
                        reject(error);
                    }else{
                        resolve(new Field(idField,name,direction, phone))
                    }
                });

        })
    }        

    static getField(field){
        return new Promise(function (resolve,reject){
            dbCOnn.query(GET_FIELD, [field], function (error, result){
                if (error){
                    reject(error);
                }else{
                    const {idField,name,direction, phone} = result[0];
                    resolve(new Field(idField,name,direction, phone));
                }
            });
        })
        
    }

    static getFieldByName(name){
        console.log('getFieldByName');
        return new Promise(function (resolve,reject){
            console.log('getFieldByName db');
            dbCOnn.query(GET_FIELD_BY_NAME, [name], function (error, result){
                if (error){
                    reject(error);
                
                }else{
                    console.log('else');
                    if (result[0]){
                        console.log('encontro');
                        const {idField,name,direction, phone} = result[0];
                        resolve(new Field(idField,name,direction, phone))
                    }else{
                        console.log('not found');
                        resolve('NOT Found');    
                    }
                    
                }
            });
        })
        
    }    

    static getAllFields(){
        console.log('getAllFields');
        return new Promise(function (resolve,reject){
            console.log('getAllFields db');
            dbCOnn.query(GET_ALL_FIELDS, function (error, result){
                if (error){
                    reject(error);                
                }else{
                    console.log('else');
                    if (result[0]){
                        console.log('encontro');
                        resolve(result)
                    }else{
                        console.log('not found');
                        resolve('NOT Found');    
                    }
                    
                }
            });
        })
        
    }
    
    static updateField(idField,name,direction, phone){
        console.log('updateField');
        return new Promise(function (resolve,reject){
                const updateField = { 
                    name,direction, phone,idField
                };
                dbCOnn.query(UPDATE_FIELD, [updateField], function (error, result){
                    if (error){
                        reject(error);
                    }else{
                        resolve(new Player(idField,name,direction, phone))
                    }
                });

        })
    }


    static deleteField(idField){
        console.log('deleteField');
        return new Promise(function (resolve,reject){      

                        dbCOnn.query(DELETE_FIELD, [idField], function (error, result){
                            if (error){
                                reject(error);
                            }else{
                                resolve(result);  
                            }
                        });
                    
            
        })
    }    
}

module.exports = Field;
